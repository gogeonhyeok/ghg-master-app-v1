import styles from "./frogchat.module.css";

// Keep the supplied SVGs intact: their own viewBoxes preserve every detail and
// their native palette. Animate the surrounding group rather than their paths.
export function WoodlandFrogArtwork() {
  return (
    <g className={`${styles.frogBody} ${styles.suppliedFrog}`}>
      <image href="/frogchat/woodland-frog.svg" x="30" y="3" width="100" height="110" preserveAspectRatio="xMidYMax meet" />
    </g>
  );
}

export function PixelFrogArtwork() {
  return (
    <g className={`${styles.frogBody} ${styles.suppliedFrog}`}>
      <image href="/frogchat/pixel-frog.svg" x="16" y="12" width="128" height="104" preserveAspectRatio="xMidYMax meet" />
    </g>
  );
}
