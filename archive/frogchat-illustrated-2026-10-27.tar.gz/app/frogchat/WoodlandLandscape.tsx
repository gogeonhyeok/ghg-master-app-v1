import IllustratedLandscape from "./IllustratedLandscape";

export default function WoodlandLandscape() {
  return <IllustratedLandscape pond="woodland" />;
}
