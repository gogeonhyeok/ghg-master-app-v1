import IllustratedLandscape from "./IllustratedLandscape";

export default function PixelLandscape() {
  return <IllustratedLandscape pond="pixel" />;
}
