import type { Metadata } from "next";
import FrogChat from "./FrogChat";

export const metadata: Metadata = {
  title: "Frogchat · A little pond, a little conversation",
  description: "Hop between a clover pond, a painted woodland, and pixel springs, by day or by night. Meet other frogs and send a croak.",
};

export default function FrogChatPage() {
  return <FrogChat />;
}
