# Pond artwork

The two frog SVGs were supplied by the user as Linearity Curve exports, in this
order: the detailed painted frog for Whispering woods and the angular frog for
Pixel springs. They are used as separate SVG image resources, so their original
viewBoxes, path geometry, colors, and transparency remain intact. Only XML/DTD
headers were omitted when placing the assets in `public`.

Assets, relative to the Next.js root:

- `public/frogchat/woodland-frog.svg` — supplied painted frog.
- `public/frogchat/pixel-frog.svg` — supplied angular frog.
- `public/frogchat/woodland-day.webp` and `woodland-night.webp` — painted forest.
- `public/frogchat/pixel-day.webp` and `pixel-night.webp` — faceted spring.

The four backgrounds were made with the **built-in imagegen tool**, using the
supplied frogs as style references only; no generated frog is included in them.
Night variants use their respective day backgrounds as edit references. Original
1536 × 1024 PNG outputs were encoded as WebP at quality 88. Next.js Image serves
responsive sizes. No external image service or image API key is needed at runtime.
The foliage, ripples, and platforms remain separate from the resident artwork.

## Final prompt set

### Woodland day

Use case: stylized-concept. Asset type: finished background illustration for an interactive frog chat pond, wide landscape 3:2. Input image: reference ONLY for the detailed painterly green frog's visual style and lime/olive colors; do NOT put the frog or any characters in the output. Create a richly painted, polished hand-animated fantasy forest pond in DAYLIGHT: old mossy deciduous trees with intricate foliage frame the left and right edges, fern fronds, small white wildflowers, warm amber speckles of sun through leaves, distant soft forest silhouettes and atmospheric depth. A tranquil shallow jade/teal pond fills the lower 60 percent with subtle reflections and a few small distant lily pads. Composition important: horizon in upper 35 percent, foreground lower central water stays calm and unobstructed for interactive frog sprites and lily pads overlaid later. Center crop must still work in a narrow mobile window. Eye level close to the water, cozy intimate nature, sophisticated textured gouache and watercolor, detailed organic shapes, fresh yellow-green leaves and cool deep green shadows, soft warm sunlight, refined natural edges, beautiful layered lighting. Not flat clip art, not geometric conifers, not a UI screenshot. No foreground lily platforms, no buildings, no frogs, no people, no animals, no words, no frames, no watermark.

### Woodland night

Use case: lighting-weather. Edit this exact forest pond background into NIGHT. Keep its composition, viewpoint, tree trunks, branches, rocks, wildflowers, bank silhouettes, waterline, and all spatial geometry exactly unchanged, so the day and night images can crossfade seamlessly in an interactive scene. Keep the same detailed hand-painted animation/gouache style. Change only the lighting and atmosphere: rich midnight petrol blues and deep forest greens, gentle silvery blue moonlight through the canopy, soft moonlit reflection down the central water, a few warm yellow-green fireflies along the banks, distant subtle blue haze. Very peaceful, magical but natural. Retain enough visible botanical and water details; don't crush everything into black. Bright sunlight and yellow daytime reflections must be replaced with cool night light. No new buildings or props. No frogs, people or other characters, no text or UI, no watermark. Same exact landscape framing and dimensions.

### Pixel day

Use case: stylized-concept. Asset type: polished game environment background for a frog chat pond, landscape 3:2. Input image: reference ONLY for its visual language: hard-edged angular planes, lime-green highlights, deep petrol-green/navy shadows, cream accents. Do not include the frog or any characters. Create a beautiful faceted retro adventure forest pond during DAYTIME, a sophisticated low-poly 2D story-game environment using crisp polygonal surfaces and sharply stepped details, no outlines. Frame the sides with layered angular moss-covered stone banks, broad angular leaves, fern silhouettes, tiny cream flowers and stone ledges. A small spring waterfall in the far right midground tumbles from a rock ledge into tranquil turquoise water. Distant angular tree crowns layer upward into a pale cyan sky with soft stylized light. Richly layered depth with fresh bright greens against ink-blue shadows, restrained geometry, fine designed details, a cohesive confident limited palette. Horizon around upper 35 percent. Lower 60 percent largely tranquil open teal water so separate frog sprites and platforms can be overlaid. Keep central foreground uncluttered, avoid central islands or foreground platforms. Center crop usable on mobile. It must match the reference frog's confident angular illustration style rather than giant Minecraft blocks or soft rounded cartoon art. No frogs, no characters, no text, no UI, no borders, no watermark.

### Pixel night

Use case: lighting-weather. Edit this EXACT faceted game forest pond into NIGHT. Keep all scene geometry, framing, tree shapes, rock banks, polygon facets, waterfall, flowers, waterline, and viewpoint exactly unchanged for a seamless day/night background crossfade. Keep the crisp hard-edged angular limited-palette illustration style. Only change lighting and atmosphere: midnight teal and deep navy/petrol shadows, cool moonlight in the sky, subtle silvery cyan edges on rocks and leaves, softly luminous pale blue waterfall and its reflection, some distant tiny stars through the sky opening. Retain rich readable dark colors and gentle reflected light on the open foreground water. A handful of tiny cool firefly glints around the banks. Replace all bright daytime yellow sunshine with moonlit cool tones. No added buildings, central platforms, characters or frogs. No text, no UI, no watermark. Same dimensions and exact composition as the input.
