import Image from "next/image";
import type { PondId } from "@/lib/frogchat/ponds";
import styles from "./frogchat.module.css";

export default function IllustratedLandscape({ pond }: { pond: Exclude<PondId, "classic"> }) {
  return (
    <div className={`${styles.landscape} ${styles.illustratedLandscape}`} aria-hidden="true">
      <Image src={`/frogchat/${pond}-day.webp`} alt="" fill sizes="(max-width: 850px) 100vw, (max-width: 1440px) 75vw, 1024px" className={styles.backdropDay} loading="eager" />
      <Image src={`/frogchat/${pond}-night.webp`} alt="" fill sizes="(max-width: 850px) 100vw, (max-width: 1440px) 75vw, 1024px" className={styles.backdropNight} loading="eager" />
      <div className={styles.sceneVignette} />
      <div className={styles.waterGlint} />
      <div className={styles.ambientLights}>
        {[0, 1, 2, 3, 4, 5].map(index => <span key={index} style={{ left: `${12 + index * 15}%`, top: `${35 + (index % 3) * 17}%`, animationDelay: `${index * -1.3}s` }} />)}
      </div>
    </div>
  );
}
