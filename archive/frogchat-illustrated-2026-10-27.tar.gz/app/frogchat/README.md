# Frogchat

Visit `/frogchat` to automatically join Clover pond. Each visit gets an
anonymous frog. **Hop** randomly takes you to one of the other two ponds: the
painted Whispering woods or retro Pixel springs. Each has its own frog artwork,
day/night scenery, residents, and chat history. Hopping releases your previous
session and gives you a new frog; it clears your draft and leaves the old chat
behind. Your day/night choice stays with you. The default follows your local
time (day from 06:00 to 18:00).

Invite links include the current pond: `/frogchat?pond=woodland` or
`/frogchat?pond=pixel`; `/frogchat` is the original pond. Friends must be in the
same pond to see each other. All three ponds share the same MongoDB and Redis
configuration; no additional service is needed. Older records without a pond
identifier belong to Clover pond. The server binds each session token to its pond
and filters snapshots and notifications accordingly.

The woodland and pixel frogs use the supplied SVG artwork, preserving its native
paths and colors. Their day/night backgrounds are generated illustrations stored
as optimized WebP files in `public/frogchat`. The painted forest and faceted spring
have matching lily pads/platforms, quiet water motion, and night fireflies. Both
backgrounds crossfade when the theme changes. See [ARTWORK.md](./ARTWORK.md) for
asset provenance and the image-generation prompts. The original Clover pond
keeps its SVG scenery and frog.

The page subscribes to `/api/frogchat/ws` for live updates. HTTP
POST requests join the pond and save croaks; Redis notifications tell connected
WebSocket instances to send fresh snapshots. There is no recurring HTTP polling. Bubbles last
ten seconds, and every new croak animates the frog for about one second. Sound is
optional and starts off. Enabling sound previews a soft, two-syllable synthesized
croak; each frog has a slightly different voice. Muting fades out active audio.
No audio files or external sound services are needed. No simulated visitors or
automated replies are used.

The route’s components, styles, sound synthesis, and UI tests live together in
`app/frogchat`. The HTTP and WebSocket handlers live in `app/api/frogchat`; shared message types,
browser connection management, server-side socket handling, Redis broadcasts, and
storage code live in `lib/frogchat`.

## Shared storage

The existing `MONGODB_URI` (or `MONGODB_URL`) enables shared storage across Next.js
instances. `MONGODB_DB` selects the database, defaulting to `ghg-master-api-v1`.
The application creates `frogchat_residents` and `frogchat_messages`, with TTL
indexes. The database account needs permission to create these indexes and to
read/write the two collections. A configured database outage returns a retryable
error; it does not silently split visitors into separate ponds.

With neither MongoDB variable configured, an in-memory pond works for development
or a single long-running Node.js server. It resets on restart and is not suitable
for multiple instances or serverless deployment. Use MongoDB in those environments.

The browser sends a heartbeat over its socket every 25 seconds. Heartbeats renew
presence and reconcile snapshots, including missed broadcasts and expired
residents/messages. Visitors leave on page exit or expire after 90 seconds without
a presence renewal. Other visitors see expired residents removed on their next
snapshot (normally within one heartbeat). Socket disconnection alone does not
delete a session, so reconnects preserve the same frog. Chat
history in each pond contains the latest 100 messages from the last 30 minutes. Session tokens
are private to each page visit, are hashed in storage, and are never exposed in
other visitors’ snapshots. Message requests are length-limited, rate-limited per
frog, and deduplicated on retry. All messages are rendered as plain text.

## Vercel WebSockets

The repository's `vercel.json` enables **Fluid compute**, which Vercel requires
for WebSockets. Redeploy after changing this setting; a working local
`vercel dev` socket does not confirm that the deployed runtime supports upgrades.
Configure these server-only
variables in the deployment environment (and locally when using Vercel dev):

| Variable | Purpose |
| --- | --- |
| `MONGODB_URI` or `MONGODB_URL` | Existing shared MongoDB storage. |
| `MONGODB_DB` | Optional database name; default `ghg-master-api-v1`. |
| `FROGCHAT_REDIS_URL` or `REDIS_URL` | Redis TCP connection URL, e.g. `rediss://default:PASSWORD@HOST:PORT`. The service must support Redis Pub/Sub; an HTTP REST endpoint/token is insufficient. |
| `FROGCHAT_REDIS_CHANNEL` | Optional broadcast channel. Defaults to `frogchat:${VERCEL_ENV}` on Vercel, or `frogchat:development` elsewhere. Use the same value for instances sharing one pond. |

Use a separate database/channel to isolate preview deployments from production. Production instances
must share both storage and the channel. Vercel deployments fail requests when
MongoDB or Redis is missing instead of silently creating isolated in-memory ponds.
A Redis subscriber is shared by sockets in each instance; subscription failure
closes those sockets so they reconnect and resynchronize.

The server accepts a private session token in the first socket frame, never in a
URL. It checks the browser's Origin before upgrading, limits frames to 4 KiB, and
closes connections that do not authenticate within 10 seconds. Only authenticated
clients receive snapshots. Redis carries invalidation events, not private tokens.
Existing HTTP message length limits, rate limits, and retry deduplication remain.

Connections reconnect with backoff after network failures or Vercel's function
time limit. The socket route sets `maxDuration = 60` to support Hobby deployments
with a 60-second function limit. The browser reconnects automatically when that
limit closes a socket. Each reconnect authenticates
the existing session, subscribes before reading its initial snapshot, and restores
recent history. Expired sessions automatically join again. HTTP GET remains
available for one-off diagnostics but the browser does not poll it.

### Local development

The `upgradeWebSocket()` API requires the Vercel runtime. Plain `next dev` and
`next start` do not provide that runtime. The repo includes a compatible Vercel CLI:

```sh
npm install
npx vercel login          # if this machine is not authenticated
npx vercel link           # select the intended existing Vercel project
npm run dev:vercel
```

Configure the shared-service variables locally before starting. `dev:vercel` runs
`vercel dev`, which runs Next.js through the configured `next dev` command. Keep
`dev` as `next dev` to avoid recursive CLI invocation. No deployment is performed by these
commands.

The repository's `vercel.json` explicitly selects Next.js and `next dev`, so the
CLI loads its WebSocket runtime even when the linked project's framework preset
is unset. Restart `npm run dev:vercel` after changing this configuration.
The origin check uses the CLI's public loopback `VERCEL_URL` (or forwarded
loopback host) during development; production requests still require the
browser's origin host to match Host.

Match the Redis URL scheme to the endpoint: `rediss://` requires TLS, whereas
`redis://` is unencrypted. Redis Cloud Free Essentials endpoints do not support
TLS; using `redis://` sends credentials over an unencrypted connection. For an
encrypted connection, use a TLS-enabled service or plan.

Open `/frogchat` in two tabs and send a croak. In browser DevTools → Network,
`/api/frogchat/ws` should show a WebSocket upgrade and incoming snapshot frames.
The recurring GET requests should be absent; POST join/message and DELETE leave
requests remain. Briefly disconnect/reconnect a tab and confirm its history and
frog recover. For deployments, repeat with browsers connected to different
instances to verify the Redis configuration.

Official references: [Vercel WebSockets](https://vercel.com/docs/functions/websockets)
and [upgradeWebSocket API / local development](https://vercel.com/docs/functions/functions-api-reference/vercel-functions-package#upgradewebsocket).

### Deployed page stays on “Reconnecting”

The composer becomes available after the authenticated WebSocket sends its first
snapshot. A successful HTTP join alone does not mean the socket connected.
In browser DevTools → Network, inspect `/api/frogchat/ws`:

- `101`: the upgrade succeeded; inspect incoming frames and the close code.
  An error frame or close code `1013` can indicate a Redis subscription or
  database failure. Check the corresponding Vercel function logs and Redis
  connection limits.
- `403`: the Origin check rejected the request; compare the page's host with
  the host received by the function. Keep the same-origin protection enabled.
- `503`: check deployed MongoDB/Redis configuration and runtime support for
  `upgradeWebSocket`. Ensure the deployment uses Fluid compute.
- `502` before any socket frames: check Fluid compute first. An older project
  can still have it disabled even though local WebSockets work. Deploy the
  repository's `"fluid": true` configuration, or enable it in Settings → Functions
  and redeploy.

Environment changes and `vercel.json` changes require a new deployment. Settings
in a local `.env.local` file do not configure the Vercel deployment environment.

## Checks

```sh
npx eslint app/frogchat app/api/frogchat lib/frogchat
npm test -- --runInBand --watchman=false lib/frogchat app/api/frogchat app/frogchat
```

The tests cover room isolation, random hopping, invitation URLs, stale joins,
local day/night defaults, authenticated broadcasts, heartbeat expiry, reconnect
recovery, no HTTP polling, and Redis coordination between isolated instance hubs. The wire
integration test opens real WebSocket connections on a temporary loopback port;
it requires permission to listen locally. Redis coordination uses a test double;
verify the configured Redis service in a Vercel preview before production use.
