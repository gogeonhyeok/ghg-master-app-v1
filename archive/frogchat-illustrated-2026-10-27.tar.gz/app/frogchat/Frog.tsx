import type { CSSProperties } from "react";
import type { Frog as PondFrog, PondMessage } from "@/lib/frogchat/types";
import { DEFAULT_POND, type PondId } from "@/lib/frogchat/ponds";
import { WoodlandFrogArtwork, PixelFrogArtwork } from "./PondFrogArtwork";
import FrogArtwork from "./FrogArtwork";
import styles from "./frogchat.module.css";

export function FrogPortrait({ color, croaking = false, pond = DEFAULT_POND }: { color: string; croaking?: boolean; pond?: PondId }) {
  return (
    <svg viewBox="0 0 160 130" fill="none" aria-hidden="true" className={`${styles.frogDrawing} ${croaking ? styles.croaking : ""}`} style={{ "--frog-color": color } as CSSProperties}>
      <ellipse cx="80" cy="115" rx="54" ry="8" fill="#325838" opacity=".12" />
      {pond === "woodland" ? <WoodlandFrogArtwork /> : pond === "pixel" ? <PixelFrogArtwork /> : <FrogArtwork />}
      <g className={styles.croakLines} stroke="#588557" strokeWidth="2.5" strokeLinecap="round"><path d="M18 51L11 47M16 65H7M142 51L149 47M144 65H153" /></g>
    </svg>
  );
}

export default function Frog({ frog, message, isSelf, croaking, pond = DEFAULT_POND }: { pond?: PondId; frog: PondFrog; message?: PondMessage; isSelf: boolean; croaking: boolean }) {
  return (
    <div className={`${styles.resident} ${isSelf ? styles.selfResident : ""}`} aria-label={`${frog.name}${isSelf ? ", your frog" : ""}`} style={{ "--resident-color": frog.color } as CSSProperties}>
      {message && <div key={message.id} className={styles.bubble}>{message.text}</div>}
      <div className={styles.frogOnPad}>
        <svg className={styles.lilyPad} viewBox="0 0 180 62" aria-hidden="true">
          {pond === "pixel" ? <>
            <path d="m9 36 24-19 49-8 63 10 24 17-29 17-61 6-47-9Z" fill="#143d3e" opacity=".35" />
            <path d="m16 27 24-16 54-5 51 12 17 14-25 15-51 7-51-11Z" fill="#244c42" />
            <path d="m16 27 24-16 54-5 51 12 17 14-51 7-52-4Z" fill="#5d8e45" />
            <path d="m40 11 54-5 51 12-47 3-53 5-29 1Z" fill="#92b34e" /><path d="m59 35 52 4 51-7-25 15-51 7Z" fill="#376642" />
            <path d="m40 11 20 3-15 12-29 1Zm92 3 13 4 17 14-18-3Z" fill="#b2c666" />
          </> : pond === "woodland" ? <>
            <ellipse cx="90" cy="39" rx="82" ry="18" fill="#123f36" opacity=".22" />
            <ellipse className={styles.padRipple} cx="90" cy="37" rx="88" ry="21" fill="none" stroke="#dfedc0" strokeWidth="1" opacity=".4" />
            <path d="M91 8C126 2 165 15 169 29C172 44 131 54 88 53C44 54 10 44 12 29C15 13 54 4 91 8L84 31Z" fill="#456e35" />
            <path d="M91 8C123 5 157 14 164 26C156 41 120 46 86 46C53 47 23 41 16 29C23 15 56 6 91 8L84 31Z" fill="#7f9d43" />
            <path d="M84 31 32 25m52 6-29 10m29-10 45 9m-45-9 62-10" stroke="#bed078" strokeWidth="1.2" opacity=".55" />
            <path d="M26 23Q47 10 76 12M103 11Q139 12 154 23" stroke="#d4dfa3" strokeWidth="2" strokeLinecap="round" opacity=".4" />
          </> : <><ellipse cx="90" cy="34" rx="84" ry="24" fill="#749d63" opacity=".18" /><path d="M90 5C136 5 170 14 170 30S136 53 90 53S10 45 10 30S43 5 90 5L83 29L111 7" fill={isSelf ? "#6da45f" : "#8cb57d"} /><path d="M30 29L76 31M99 37L142 40M59 44L81 35" stroke="#53894f" strokeWidth="1.5" opacity=".45" /></>}
        </svg>
        <FrogPortrait pond={pond} color={frog.color} croaking={croaking} />
      </div>
      <span className={styles.frogName}>{(isSelf || pond !== DEFAULT_POND) && <span className={pond === DEFAULT_POND ? styles.youDot : styles.residentDot} />}{frog.name}{isSelf && <small>you</small>}</span>
    </div>
  );
}
